namespace GestaoResponsaveisAPI.Models
{
    public class ResponsavelCreateDTO
    {
        public string Nome { get; set; }
        public string Telefone { get; set; }
    }
}
